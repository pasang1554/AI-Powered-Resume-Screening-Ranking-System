"""
ResumeAI Pro - Neural Recruitment Intelligence Platform
Version: 3.0 - Enterprise Edition
Features: Multi-dimensional analytics, neural glassmorphism, semantic skill extraction
"""
import streamlit as st
import pandas as pd
import numpy as np
import altair as alt
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from utils import (
    extract_text_from_pdf, 
    calculate_similarity, 
    find_missing_skills,
    extract_semantic_skills,
    calculate_skill_depth,
    detect_bias_indicators,
    evaluate_resume_with_groq
)
from groq import Groq

import time
from datetime import datetime
import base64
from io import BytesIO

# ============================================================
# PAGE CONFIGURATION & THEME SYSTEM
# ============================================================
st.set_page_config(
    page_title="ResumeAI Pro | Neural Recruitment Intelligence",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state for theme persistence
if 'theme' not in st.session_state:
    st.session_state.theme = 'dark'
if 'analysis_history' not in st.session_state:
    st.session_state.analysis_history = []

# ============================================================
# ADVANCED CSS - NEURAL GLASSMORPHISM 2.0
# ============================================================
def get_custom_css(theme='dark'):
    is_dark = theme == 'dark'
    bg_primary = "#0a0a0f" if is_dark else "#f8fafc"
    bg_secondary = "#161622" if is_dark else "#ffffff"
    text_primary = "#ffffff" if is_dark else "#1e293b"
    text_secondary = "#94a3b8" if is_dark else "#64748b"
    accent_gradient = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" if is_dark else "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)"
    glass_bg = "rgba(255, 255, 255, 0.03)" if is_dark else "rgba(255, 255, 255, 0.7)"
    border_color = "rgba(255, 255, 255, 0.08)" if is_dark else "rgba(0, 0, 0, 0.08)"
    
    return f"""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap');
    
    * {{
        font-family: 'Inter', sans-serif;
    }}
    
    .stApp {{
        background: {bg_primary};
        background-image: 
            radial-gradient(at 0% 0%, rgba(102, 126, 234, 0.15) 0px, transparent 50%),
            radial-gradient(at 100% 0%, rgba(118, 75, 162, 0.15) 0px, transparent 50%),
            radial-gradient(at 100% 100%, rgba(236, 72, 153, 0.1) 0px, transparent 50%),
            radial-gradient(at 0% 100%, rgba(59, 130, 246, 0.1) 0px, transparent 50%);
        background-attachment: fixed;
    }}
    
    /* Animated Background Mesh */
    @keyframes meshMove {{
        0% {{ background-position: 0% 50%; }}
        50% {{ background-position: 100% 50%; }}
        100% {{ background-position: 0% 50%; }}
    }}
    
    /* Neural Card System */
    .neural-card {{
        background: {glass_bg};
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid {border_color};
        border-radius: 20px;
        padding: 24px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }}
    
    .neural-card::before {{
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05), transparent);
        transition: left 0.7s;
    }}
    
    .neural-card:hover::before {{
        left: 100%;
    }}
    
    .neural-card:hover {{
        transform: translateY(-4px) scale(1.01);
        box-shadow: 0 20px 40px rgba(0,0,0,0.3), 0 0 0 1px rgba(102, 126, 234, 0.2);
        border-color: rgba(102, 126, 234, 0.3);
    }}
    
    /* Glowing Border Effect */
    .glow-border {{
        position: relative;
    }}
    
    .glow-border::after {{
        content: '';
        position: absolute;
        inset: -1px;
        border-radius: 20px;
        padding: 1px;
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.5), rgba(118, 75, 162, 0.5), rgba(236, 72, 153, 0.5));
        -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        -webkit-mask-composite: xor;
        mask-composite: exclude;
        opacity: 0;
        transition: opacity 0.3s;
    }}
    
    .glow-border:hover::after {{
        opacity: 1;
    }}
    
    /* Metric Cards with Gradient Text */
    .metric-container {{
        display: flex;
        flex-direction: column;
        gap: 8px;
    }}
    
    .metric-label {{
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: {text_secondary};
    }}
    
    .metric-value {{
        font-size: 36px;
        font-weight: 800;
        background: {accent_gradient};
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        line-height: 1.2;
    }}
    
    .metric-delta {{
        font-size: 13px;
        color: #10b981;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 4px;
    }}
    
    /* Skill Tags with Glow */
    .skill-tag {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(102, 126, 234, 0.15);
        border: 1px solid rgba(102, 126, 234, 0.3);
        color: #667eea;
        padding: 6px 14px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.3s;
        cursor: default;
    }}
    
    .skill-tag:hover {{
        background: rgba(102, 126, 234, 0.3);
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(102, 126, 234, 0.4);
    }}
    
    .skill-tag.missing {{
        background: rgba(239, 68, 68, 0.15);
        border-color: rgba(239, 68, 68, 0.3);
        color: #ef4444;
    }}
    
    .skill-tag.missing:hover {{
        background: rgba(239, 68, 68, 0.3);
        box-shadow: 0 0 20px rgba(239, 68, 68, 0.4);
    }}
    
    /* Status Badges */
    .status-badge {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }}
    
    .status-selected {{
        background: rgba(16, 185, 129, 0.15);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.3);
        box-shadow: 0 0 15px rgba(16, 185, 129, 0.2);
    }}
    
    .status-rejected {{
        background: rgba(239, 68, 68, 0.15);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.3);
    }}
    
    /* Progress Bar Animation */
    @keyframes progressFill {{
        from {{ width: 0%; }}
        to {{ width: var(--progress-width); }}
    }}
    
    .custom-progress {{
        width: 100%;
        height: 8px;
        background: rgba(255,255,255,0.1);
        border-radius: 4px;
        overflow: hidden;
        position: relative;
    }}
    
    .custom-progress-fill {{
        height: 100%;
        border-radius: 4px;
        background: linear-gradient(90deg, #667eea, #764ba2);
        transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }}
    
    .custom-progress-fill::after {{
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
        animation: shimmer 2s infinite;
    }}
    
    @keyframes shimmer {{
        0% {{ transform: translateX(-100%); }}
        100% {{ transform: translateX(100%); }}
    }}
    
    /* Floating Action Button */
    .fab-container {{
        position: fixed;
        bottom: 30px;
        right: 30px;
        z-index: 999;
    }}
    
    /* Section Headers */
    .section-header {{
        font-size: 24px;
        font-weight: 700;
        color: {text_primary};
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
    }}
    
    .section-subtitle {{
        font-size: 14px;
        color: {text_secondary};
        margin-top: -20px;
        margin-bottom: 24px;
    }}
    
    /* Candidate Card */
    .candidate-row {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px;
        background: {glass_bg};
        border: 1px solid {border_color};
        border-radius: 16px;
        margin-bottom: 12px;
        transition: all 0.3s;
    }}
    
    .candidate-row:hover {{
        transform: translateX(8px);
        border-color: rgba(102, 126, 234, 0.3);
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }}
    
    /* Animated Loading */
    @keyframes pulse-ring {{
        0% {{ transform: scale(0.8); opacity: 0.5; }}
        100% {{ transform: scale(1.3); opacity: 0; }}
    }}
    
    .loading-ring {{
        position: relative;
        width: 60px;
        height: 60px;
    }}
    
    .loading-ring::before,
    .loading-ring::after {{
        content: '';
        position: absolute;
        inset: 0;
        border-radius: 50%;
        border: 3px solid transparent;
        border-top-color: #667eea;
        animation: spin 1s linear infinite;
    }}
    
    .loading-ring::after {{
        border-top-color: #764ba2;
        animation-duration: 1.5s;
        animation-direction: reverse;
    }}
    
    @keyframes spin {{
        to {{ transform: rotate(360deg); }}
    }}
    
    /* Custom Scrollbar */
    ::-webkit-scrollbar {{
        width: 8px;
        height: 8px;
    }}
    
    ::-webkit-scrollbar-track {{
        background: transparent;
    }}
    
    ::-webkit-scrollbar-thumb {{
        background: rgba(102, 126, 234, 0.3);
        border-radius: 4px;
    }}
    
    ::-webkit-scrollbar-thumb:hover {{
        background: rgba(102, 126, 234, 0.5);
    }}
    
    /* Hide Streamlit Elements */
    #MainMenu {{visibility: hidden;}}
    footer {{visibility: hidden;}}
    header {{visibility: hidden;}}
    
    /* Tab Styling */
    .stTabs [data-baseweb="tab-list"] {{
        gap: 8px;
        background: {glass_bg};
        padding: 8px;
        border-radius: 12px;
        border: 1px solid {border_color};
    }}
    
    .stTabs [data-baseweb="tab"] {{
        height: 44px;
        border-radius: 8px;
        padding: 0 20px;
        font-weight: 600;
        color: {text_secondary};
        transition: all 0.3s;
    }}
    
    .stTabs [aria-selected="true"] {{
        background: {accent_gradient} !important;
        color: white !important;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }}
    
    /* Button Enhancements */
    .stButton > button {{
        background: {accent_gradient};
        color: white;
        border: none;
        border-radius: 12px;
        padding: 12px 24px;
        font-weight: 600;
        transition: all 0.3s;
        position: relative;
        overflow: hidden;
    }}
    
    .stButton > button:hover {{
        transform: translateY(-2px);
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
    }}
    
    .stButton > button:active {{
        transform: translateY(0);
    }}
</style>
"""

# Apply CSS
st.markdown(get_custom_css(st.session_state.theme), unsafe_allow_html=True)

# ============================================================
# SIDEBAR - INTELLIGENT CONTROLS
# ============================================================
with st.sidebar:
    # Logo Area with Animation
    st.markdown("""
        <div style="text-align: center; margin-bottom: 30px;">
            <div style="font-size: 48px; margin-bottom: 10px;">🧠</div>
            <h1 style="margin: 0; font-size: 24px; font-weight: 800; background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">ResumeAI Pro</h1>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #94a3b8; letter-spacing: 2px; text-transform: uppercase;">Neural Recruitment</p>
        </div>
    """, unsafe_allow_html=True)
    
    st.markdown("<hr style='border: none; height: 1px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent); margin: 20px 0;'>", unsafe_allow_html=True)
    
    # File Upload with Enhanced UX
    st.markdown("""
        <div style="margin-bottom: 10px;">
            <span style="font-size: 14px; font-weight: 600; color: #e2e8f0;">📄 Upload Resumes</span>
            <p style="font-size: 12px; color: #64748b; margin: 4px 0 0 0;">PDF format supported • Max 10MB each</p>
        </div>
    """, unsafe_allow_html=True)
    
    uploaded_files = st.file_uploader(
        "", 
        type=["pdf"], 
        accept_multiple_files=True,
        label_visibility="collapsed"
    )
    
    if uploaded_files:
        st.markdown(f"""
            <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 12px; margin: 10px 0;">
                <span style="color: #10b981; font-weight: 600; font-size: 13px;">✓ {len(uploaded_files)} file(s) ready</span>
            </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<hr style='border: none; height: 1px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent); margin: 20px 0;'>", unsafe_allow_html=True)
    
    # Advanced Settings
    st.markdown("""
        <div style="margin-bottom: 15px;">
            <span style="font-size: 14px; font-weight: 600; color: #e2e8f0;">⚙️ Configuration</span>
        </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        threshold = st.slider("Match Threshold (%)", 0, 100, 65, help="Minimum score to shortlist candidate")
    with col2:
        analysis_depth = st.selectbox(
            "Analysis Depth",
            ["Standard", "Deep (Semantic)", "Expert (NER+Skills)"],
            help="Level of NLP analysis"
        )
    
    # Bias Detection Toggle
    enable_bias_check = st.toggle("🔍 Enable Bias Detection", value=True, help="Check for gendered language and bias indicators")
    
    # GROQ API Key - Hardcoded for internal use
    groq_api_key = "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"
    
    
    # Theme Toggle
    theme_col1, theme_col2 = st.columns([1, 3])
    with theme_col1:
        if st.button("🌙/☀️", help="Toggle Dark/Light Mode"):
            st.session_state.theme = 'light' if st.session_state.theme == 'dark' else 'dark'
            st.rerun()
    with theme_col2:
        st.markdown(f"<p style='margin: 8px 0 0 0; font-size: 12px; color: #64748b;'>{st.session_state.theme.title()} Mode Active</p>", unsafe_allow_html=True)
    
    st.markdown("<hr style='border: none; height: 1px; background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent); margin: 20px 0;'>", unsafe_allow_html=True)
    
    # Quick Stats
    if st.session_state.analysis_history:
        st.markdown("""
            <div style="margin-bottom: 15px;">
                <span style="font-size: 14px; font-weight: 600; color: #e2e8f0;">📊 Session Analytics</span>
            </div>
        """, unsafe_allow_html=True)
        total_analyzed = sum(len(h['candidates']) for h in st.session_state.analysis_history)
        st.metric("Total Processed", f"{total_analyzed}", f"{len(st.session_state.analysis_history)} jobs")

# ============================================================
# MAIN HEADER - HERO SECTION
# ============================================================
st.markdown("""
    <div style="text-align: center; margin-bottom: 40px; padding: 40px 0;">
        <h1 style="font-size: 48px; font-weight: 800; margin: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #ec4899 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -1px;">
            Neural Recruitment Intelligence
        </h1>
        <p style="font-size: 18px; color: #64748b; margin: 16px 0 0 0; max-width: 600px; margin-left: auto; margin-right: auto;">
            AI-powered semantic resume analysis with multi-dimensional candidate scoring
        </p>
    </div>
""", unsafe_allow_html=True)

# ============================================================
# JOB DESCRIPTION INPUT - RICH TEXT AREA
# ============================================================
jd_container = st.container()
with jd_container:
    st.markdown("""
        <div class="neural-card glow-border" style="margin-bottom: 30px;">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                <span style="font-size: 24px;">📝</span>
                <span style="font-size: 18px; font-weight: 700; color: #e2e8f0;">Job Description Analysis</span>
                <span style="background: rgba(102, 126, 234, 0.2); color: #667eea; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; margin-left: auto;">NLP READY</span>
            </div>
    """, unsafe_allow_html=True)
    
    job_description = st.text_area(
        "",
        height=180,
        placeholder="Paste comprehensive job description here... Include required skills, experience level, and qualifications for optimal AI analysis...",
        label_visibility="collapsed"
    )
    
    # JD Analysis Preview
    if job_description:
        extracted_skills = extract_semantic_skills(job_description)
        if extracted_skills:
            st.markdown("<div style='margin-top: 16px;'><span style='font-size: 12px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;'>🔍 Detected Requirements:</span></div>", unsafe_allow_html=True)
            tags_html = ""
            for skill in extracted_skills[:8]:
                tags_html += f'<span class="skill-tag">{skill}</span>'
            st.markdown(f"<div style='margin-top: 10px;'>{tags_html}</div>", unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

# ============================================================
# ANALYSIS TRIGGER
# ============================================================
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    analyze_clicked = st.button("🚀 Initiate Neural Analysis", type="primary", use_container_width=True)

# ============================================================
# ANALYSIS ENGINE
# ============================================================
if analyze_clicked:
    if not job_description:
        st.error("⚠️ Please enter a Job Description to proceed with analysis")
    elif not uploaded_files:
        st.error("⚠️ Please upload at least one resume (PDF format)")
    else:
        # Processing Pipeline
        with st.status("🧠 Initializing Neural Analysis Pipeline...", expanded=True) as status:
            
            # Stage 1: Preprocessing
            status.write("📥 Loading and parsing PDF documents...")
            time.sleep(0.5)
            
            results = []
            progress_bar = st.progress(0)
            
            for idx, file in enumerate(uploaded_files):
                status.write(f"🔍 Analyzing: **{file.name}** ({idx+1}/{len(uploaded_files)})")
                
                try:
                    # Extract text
                    resume_text = extract_text_from_pdf(file)
                    
                    if resume_text and len(resume_text) > 50:
                        # Core similarity
                        similarity_score = calculate_similarity(job_description, resume_text)
                        
                        # Semantic skill extraction
                        required_skills = extract_semantic_skills(job_description)
                        candidate_skills = extract_semantic_skills(resume_text)
                        
                        # Skill depth analysis
                        skill_depth = calculate_skill_depth(resume_text, candidate_skills[:5] if candidate_skills else [])
                        
                        # Missing skills calculation
                        missing = list(set(required_skills) - set(candidate_skills))
                        
                        # Bias detection
                        bias_flags = detect_bias_indicators(resume_text) if enable_bias_check else []
                        
                        # AI Expert Evaluation
                        ai_evaluation = None
                        if groq_api_key:
                            try:
                                client = Groq(api_key=groq_api_key)
                                ai_evaluation = evaluate_resume_with_groq(client, job_description, resume_text)
                            except Exception as e:
                                st.error(f"AI Evaluation failed: {str(e)}")

                        
                        # Calculate composite score with weightings
                        base_score = similarity_score
                        depth_bonus = min(skill_depth * 2, 10)  # Up to 10 points for skill depth
                        bias_penalty = len(bias_flags) * 5  # Penalty for bias indicators
                        
                        final_score = max(0, min(100, base_score + depth_bonus - bias_penalty))
                        
                        # Determine status
                        status_label = "Shortlisted" if final_score >= threshold else "Not Selected"
                        
                        results.append({
                            "Rank": 0,  # Will be assigned after sorting
                            "Candidate": file.name.replace(".pdf", ""),
                            "Match_Score": round(final_score, 1),
                            "Semantic_Similarity": round(similarity_score, 1),
                            "Skill_Depth": round(skill_depth, 1),
                            "Key_Skills_Matched": len(candidate_skills),
                            "Missing_Skills": missing[:5],
                            "Missing_Count": len(missing),
                            "Bias_Indicators": len(bias_flags),
                            "Status": status_label,
                            "Top_Skills": candidate_skills[:6],
                            "Analysis_Timestamp": datetime.now().strftime("%H:%M:%S"),
                            "AI_Evaluation": ai_evaluation
                        })
                        
                except Exception as e:
                    st.error(f"Error processing {file.name}: {str(e)}")
                
                progress_bar.progress((idx + 1) / len(uploaded_files))
                time.sleep(0.3)
            
            progress_bar.empty()
            
            if results:
                # Sort and assign ranks
                results = sorted(results, key=lambda x: x["Match_Score"], reverse=True)
                for i, r in enumerate(results):
                    r["Rank"] = i + 1
                
                # Store in history
                st.session_state.analysis_history.append({
                    "timestamp": datetime.now(),
                    "job_snippet": job_description[:100] + "...",
                    "candidates": results
                })
                
                status.update(label=f"✅ Analysis Complete! {len(results)} candidates processed", state="complete")
                
                # Create DataFrame
                df = pd.DataFrame(results)
                
                # ============================================================
                # RESULTS DASHBOARD - TABS
                # ============================================================
                tab1, tab2, tab3, tab4, tab5 = st.tabs([
                    "📊 Executive Overview", 
                    "🏆 Candidate Rankings", 
                    "🔬 Deep Analysis",
                    "📈 Comparative Analytics",
                    "🤖 AI Expert Insights"
                ])
                
                # ============================================================
                # TAB 1: EXECUTIVE OVERVIEW
                # ============================================================
                with tab1:
                    st.markdown("<div class='section-header'>📊 Executive Overview</div>", unsafe_allow_html=True)
                    st.markdown("<div class='section-subtitle'>Real-time recruitment intelligence dashboard with key performance indicators</div>", unsafe_allow_html=True)
                    
                    # KPI Cards Row
                    kpi_col1, kpi_col2, kpi_col3, kpi_col4 = st.columns(4)
                    
                    total_candidates = len(df)
                    shortlisted = len(df[df["Status"] == "Shortlisted"])
                    avg_score = df["Match_Score"].mean()
                    top_score = df["Match_Score"].max()
                    
                    with kpi_col1:
                        st.markdown(f"""
                            <div class="neural-card">
                                <div class="metric-container">
                                    <span class="metric-label">Total Candidates</span>
                                    <span class="metric-value">{total_candidates}</span>
                                    <span class="metric-delta">↑ Active Pool</span>
                                </div>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    with kpi_col2:
                        st.markdown(f"""
                            <div class="neural-card">
                                <div class="metric-container">
                                    <span class="metric-label">Shortlisted</span>
                                    <span class="metric-value" style="background: linear-gradient(135deg, #10b981, #34d399); -webkit-background-clip: text;">{shortlisted}</span>
                                    <span class="metric-delta">{shortlisted/total_candidates*100:.0f}% of pool</span>
                                </div>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    with kpi_col3:
                        st.markdown(f"""
                            <div class="neural-card">
                                <div class="metric-container">
                                    <span class="metric-label">Average Match</span>
                                    <span class="metric-value">{avg_score:.1f}%</span>
                                    <span class="metric-delta">Pool Quality Index</span>
                                </div>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    with kpi_col4:
                        st.markdown(f"""
                            <div class="neural-card">
                                <div class="metric-container">
                                    <span class="metric-label">Top Performer</span>
                                    <span class="metric-value" style="background: linear-gradient(135deg, #f59e0b, #fbbf24); -webkit-background-clip: text;">{top_score:.0f}%</span>
                                    <span class="metric-delta">Best Match Score</span>
                                </div>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    st.markdown("<br>", unsafe_allow_html=True)
                    
                    # Distribution Charts
                    chart_col1, chart_col2 = st.columns(2)
                    
                    with chart_col1:
                        st.markdown("""
                            <div class="neural-card" style="height: 400px;">
                                <div style="font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #e2e8f0;">Match Score Distribution</div>
                        """, unsafe_allow_html=True)
                        
                        fig_dist = go.Figure()
                        fig_dist.add_trace(go.Histogram(
                            x=df["Match_Score"],
                            nbinsx=10,
                            marker_color='rgba(102, 126, 234, 0.7)',
                            marker_line_color='rgba(102, 126, 234, 1)',
                            marker_line_width=2,
                            opacity=0.8
                        ))
                        fig_dist.add_vline(x=threshold, line_dash="dash", line_color="#ef4444", annotation_text=f"Threshold ({threshold}%)")
                        fig_dist.update_layout(
                            plot_bgcolor='rgba(0,0,0,0)',
                            paper_bgcolor='rgba(0,0,0,0)',
                            font_color='#94a3b8',
                            xaxis_title="Match Score (%)",
                            yaxis_title="Number of Candidates",
                            margin=dict(l=20, r=20, t=20, b=20),
                            showlegend=False
                        )
                        st.plotly_chart(fig_dist, use_container_width=True)
                        st.markdown("</div>", unsafe_allow_html=True)
                    
                    with chart_col2:
                        st.markdown("""
                            <div class="neural-card" style="height: 400px;">
                                <div style="font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #e2e8f0;">Selection Funnel</div>
                        """, unsafe_allow_html=True)
                        
                        funnel_data = pd.DataFrame({
                            'Stage': ['Total Applicants', 'Above Threshold', 'Shortlisted'],
                            'Count': [total_candidates, len(df[df["Match_Score"] >= threshold]), shortlisted]
                        })
                        
                        fig_funnel = go.Figure(go.Funnel(
                            y=funnel_data['Stage'],
                            x=funnel_data['Count'],
                            textposition="inside",
                            textinfo="value+percent initial",
                            opacity=0.85,
                            marker=dict(
                                color=["#64748b", "#667eea", "#10b981"],
                                line=dict(color="rgba(0,0,0,0.5)", width=2)
                            ),
                            connector=dict(line=dict(color="rgba(255,255,255,0.2)", width=2))
                        ))
                        fig_funnel.update_layout(
                            plot_bgcolor='rgba(0,0,0,0)',
                            paper_bgcolor='rgba(0,0,0,0)',
                            font_color='#94a3b8',
                            margin=dict(l=20, r=20, t=20, b=20)
                        )
                        st.plotly_chart(fig_funnel, use_container_width=True)
                        st.markdown("</div>", unsafe_allow_html=True)
                
                # ============================================================
                # TAB 2: CANDIDATE RANKINGS
                # ============================================================
                with tab2:
                    st.markdown("<div class='section-header'>🏆 Candidate Rankings</div>", unsafe_allow_html=True)
                    st.markdown("<div class='section-subtitle'>Ranked by composite AI score including semantic similarity and skill depth analysis</div>", unsafe_allow_html=True)
                    
                    # Top 3 Podium for first 3 candidates
                    if len(df) >= 3:
                        podium_cols = st.columns(3)
                        colors = ["#fbbf24", "#94a3b8", "#b45309"]  # Gold, Silver, Bronze
                        heights = ["280px", "240px", "240px"]
                        
                        for idx, (col, color, height) in enumerate(zip(podium_cols, colors, heights)):
                            candidate = df.iloc[idx]
                            with col:
                                st.markdown(f"""
                                    <div class="neural-card" style="text-align: center; height: {height}; display: flex; flex-direction: column; justify-content: center; border-top: 4px solid {color};">
                                        <div style="font-size: 48px; margin-bottom: 10px;">{"🥇" if idx==0 else "🥈" if idx==1 else "🥉"}</div>
                                        <div style="font-size: 18px; font-weight: 700; color: #e2e8f0; margin-bottom: 8px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{candidate['Candidate']}</div>
                                        <div style="font-size: 36px; font-weight: 800; color: {color}; margin: 10px 0;">{candidate['Match_Score']}%</div>
                                        <div class="status-badge status-selected" style="margin: 0 auto; width: fit-content;">{candidate['Status']}</div>
                                    </div>
                                """, unsafe_allow_html=True)
                    
                    st.markdown("<br>", unsafe_allow_html=True)
                    
                    # Full Data Table
                    st.markdown("<div class='neural-card'>", unsafe_allow_html=True)
                    
                    # Prepare display dataframe
                    display_df = df[["Rank", "Candidate", "Match_Score", "Semantic_Similarity", "Skill_Depth", "Missing_Count", "Status"]].copy()
                    display_df.columns = ["Rank", "Candidate", "Overall Match", "Semantic Similarity", "Skill Depth", "Skill Gaps", "Status"]
                    
                    st.dataframe(
                        display_df,
                        column_config={
                            "Rank": st.column_config.NumberColumn("Rank", width=60),
                            "Candidate": st.column_config.TextColumn("Candidate Name", width=200),
                            "Overall Match": st.column_config.ProgressColumn(
                                "Match Score",
                                help="Composite AI match score",
                                format="%.1f%%",
                                min_value=0,
                                max_value=100,
                            ),
                            "Semantic Similarity": st.column_config.ProgressColumn(
                                "Semantic Match",
                                format="%.1f%%",
                                min_value=0,
                                max_value=100,
                            ),
                            "Skill Depth": st.column_config.NumberColumn("Depth Score", help="Experience depth indicator", format="%.1f"),
                            "Skill Gaps": st.column_config.NumberColumn("Missing Skills", width=100),
                            "Status": st.column_config.TextColumn("Decision")
                        },
                        hide_index=True,
                        use_container_width=True,
                        height=400
                    )
                    
                    # Export Options
                    csv = df.to_csv(index=False).encode('utf-8')
                    json_data = df.to_json(orient='records')
                    
                    dl_col1, dl_col2, dl_col3 = st.columns(3)
                    with dl_col1:
                        st.download_button("📥 CSV Report", csv, f"resume_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.csv", "text/csv", use_container_width=True)
                    with dl_col2:
                        st.download_button("📄 JSON Export", json_data, f"resume_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.json", "application/json", use_container_width=True)
                    with dl_col3:
                        if st.button("🖨️ Print Report", use_container_width=True):
                            st.markdown("<script>window.print()</script>", unsafe_allow_html=True)
                    
                    st.markdown("</div>", unsafe_allow_html=True)
                
                # ============================================================
                # TAB 3: DEEP ANALYSIS
                # ============================================================
                with tab3:
                    st.markdown("<div class='section-header'>🔬 Deep Candidate Analysis</div>", unsafe_allow_html=True)
                    st.markdown("<div class='section-subtitle'>Individual candidate profiles with skill breakdown and gap analysis</div>", unsafe_allow_html=True)
                    
                    for _, candidate in df.iterrows():
                        is_shortlisted = candidate['Status'] == 'Shortlisted'
                        status_class = "status-selected" if is_shortlisted else "status-rejected"
                        status_icon = "✓" if is_shortlisted else "✕"
                        
                        with st.expander(f"#{candidate['Rank']} {candidate['Candidate']} — {candidate['Match_Score']}% Match"):
                            st.markdown(f"""
                                <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                                    <div style="flex: 1;">
                                        <div class="neural-card" style="height: 100%;">
                                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                                <span style="font-size: 18px; font-weight: 700; color: #e2e8f0;">{candidate['Candidate']}</span>
                                                <span class="status-badge {status_class}">{status_icon} {candidate['Status']}</span>
                                            </div>
                                            
                                            <div style="margin-bottom: 20px;">
                                                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                                    <span style="font-size: 13px; color: #94a3b8;">Composite Match Score</span>
                                                    <span style="font-size: 13px; font-weight: 700; color: #e2e8f0;">{candidate['Match_Score']}%</span>
                                                </div>
                                                <div class="custom-progress">
                                                    <div class="custom-progress-fill" style="width: {candidate['Match_Score']}%; background: {'linear-gradient(90deg, #10b981, #34d399)' if is_shortlisted else 'linear-gradient(90deg, #ef4444, #f87171)'};"></div>
                                                </div>
                                            </div>
                                            
                                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                                <div style="background: rgba(255,255,255,0.03); padding: 12px; border-radius: 10px;">
                                                    <div style="font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px;">Semantic Similarity</div>
                                                    <div style="font-size: 20px; font-weight: 700; color: #667eea; margin-top: 4px;">{candidate['Semantic_Similarity']}%</div>
                                                </div>
                                                <div style="background: rgba(255,255,255,0.03); padding: 12px; border-radius: 10px;">
                                                    <div style="font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 1px;">Skill Depth</div>
                                                    <div style="font-size: 20px; font-weight: 700; color: #8b5cf6; margin-top: 4px;">{candidate['Skill_Depth']}/10</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div style="flex: 1;">
                                        <div class="neural-card" style="height: 100%;">
                                            <div style="font-size: 14px; font-weight: 700; color: #e2e8f0; margin-bottom: 16px;">🎯 Matched Skills</div>
                                            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            """, unsafe_allow_html=True)
                            
                            if candidate['Top_Skills']:
                                for skill in candidate['Top_Skills']:
                                    st.markdown(f'<span class="skill-tag">{skill}</span>', unsafe_allow_html=True)
                            else:
                                st.markdown("<span style='color: #64748b; font-size: 13px;'>No specific skills detected</span>", unsafe_allow_html=True)
                            
                            st.markdown("""
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            """, unsafe_allow_html=True)
                            
                            # Missing Skills Section
                            if candidate['Missing_Skills']:
                                st.markdown("""
                                    <div class="neural-card" style="border-left: 4px solid #ef4444;">
                                        <div style="font-size: 14px; font-weight: 700; color: #ef4444; margin-bottom: 12px;">⚠️ Skill Gaps (Missing from Resume)</div>
                                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                """, unsafe_allow_html=True)
                                
                                for skill in candidate['Missing_Skills']:
                                    st.markdown(f'<span class="skill-tag missing">{skill}</span>', unsafe_allow_html=True)
                                
                                st.markdown("</div></div>", unsafe_allow_html=True)
                
                # ============================================================
                # TAB 4: COMPARATIVE ANALYTICS
                # ============================================================
                with tab4:
                    st.markdown("<div class='section-header'>📈 Comparative Analytics</div>", unsafe_allow_html=True)
                    st.markdown("<div class='section-subtitle'>Multi-candidate comparison and skill landscape analysis</div>", unsafe_allow_html=True)
                    
                    comp_col1, comp_col2 = st.columns(2)
                    
                    with comp_col1:
                        st.markdown("<div class='neural-card' style='height: 450px;'>", unsafe_allow_html=True)
                        st.markdown("<div style='font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #e2e8f0;'>Candidate Comparison Radar</div>", unsafe_allow_html=True)
                        
                        # Radar chart for top 3 candidates
                        top_3 = df.head(3)
                        categories = ['Semantic Match', 'Skill Depth', 'Skill Coverage', 'Experience Density', 'Keyword Match']
                        
                        fig_radar = go.Figure()
                        colors_radar = ['#667eea', '#10b981', '#f59e0b']
                        
                        for idx, (_, candidate) in enumerate(top_3.iterrows()):
                            values = [
                                candidate['Semantic_Similarity'],
                                candidate['Skill_Depth'] * 10,  # Scale to 100
                                max(0, 100 - candidate['Missing_Count'] * 10),
                                candidate['Skill_Depth'] * 8 + 20,
                                candidate['Match_Score']
                            ]
                            
                            fig_radar.add_trace(go.Scatterpolar(
                                r=values + [values[0]],  # Close the polygon
                                theta=categories + [categories[0]],
                                fill='toself',
                                name=candidate['Candidate'][:15],
                                line_color=colors_radar[idx],
                                fillcolor=f"rgba{tuple(list(int(colors_radar[idx].lstrip('#')[i:i+2], 16) for i in (0, 2, 4)) + [0.2])}"
                            ))
                        
                        fig_radar.update_layout(
                            polar=dict(
                                radialaxis=dict(visible=True, range=[0, 100], tickfont=dict(color='#64748b')),
                                angularaxis=dict(tickfont=dict(color='#94a3b8')),
                                bgcolor='rgba(0,0,0,0)'
                            ),
                            showlegend=True,
                            legend=dict(font=dict(color='#94a3b8')),
                            paper_bgcolor='rgba(0,0,0,0)',
                            plot_bgcolor='rgba(0,0,0,0)',
                            margin=dict(l=40, r=40, t=40, b=40)
                        )
                        st.plotly_chart(fig_radar, use_container_width=True)
                        st.markdown("</div>", unsafe_allow_html=True)
                    
                    with comp_col2:
                        st.markdown("<div class='neural-card' style='height: 450px;'>", unsafe_allow_html=True)
                        st.markdown("<div style='font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #e2e8f0;'>Skill Landscape</div>", unsafe_allow_html=True)
                        
                        # Aggregate all skills
                        all_skills = []
                        for skills in df['Top_Skills']:
                            all_skills.extend(skills)
                        
                        if all_skills:
                            skill_counts = pd.Series(all_skills).value_counts().head(10)
                            
                            fig_skills = go.Figure(go.Bar(
                                x=skill_counts.values,
                                y=skill_counts.index,
                                orientation='h',
                                marker=dict(
                                    color='rgba(102, 126, 234, 0.8)',
                                    line=dict(color='rgba(102, 126, 234, 1)', width=2)
                                )
                            ))
                            fig_skills.update_layout(
                                plot_bgcolor='rgba(0,0,0,0)',
                                paper_bgcolor='rgba(0,0,0,0)',
                                font_color='#94a3b8',
                                xaxis_title="Frequency",
                                yaxis=dict(tickfont=dict(size=12)),
                                margin=dict(l=20, r=20, t=20, b=20)
                            )
                            st.plotly_chart(fig_skills, use_container_width=True)
                        else:
                            st.info("No skills data available for visualization")
                        
                        st.markdown("</div>", unsafe_allow_html=True)
                    
                    # Scatter plot analysis
                    st.markdown("<div class='neural-card' style='margin-top: 20px;'>", unsafe_allow_html=True)
                    st.markdown("<div style='font-size: 16px; font-weight: 700; margin-bottom: 20px; color: #e2e8f0;'>Score Correlation Analysis</div>", unsafe_allow_html=True)
                    
                    fig_scatter = px.scatter(
                        df,
                        x="Semantic_Similarity",
                        y="Skill_Depth",
                        size="Match_Score",
                        color="Status",
                        hover_name="Candidate",
                        color_discrete_map={"Shortlisted": "#10b981", "Not Selected": "#ef4444"},
                        size_max=50
                    )
                    fig_scatter.update_layout(
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        font_color='#94a3b8',
                        xaxis_title="Semantic Similarity (%)",
                        yaxis_title="Skill Depth Score",
                        legend_title="Status"
                    )
                    st.plotly_chart(fig_scatter, use_container_width=True)
                    st.markdown("</div>", unsafe_allow_html=True)
                    
                # ============================================================
                # TAB 5: AI EXPERT INSIGHTS
                # ============================================================
                with tab5:
                    st.markdown("<div class='section-header'>🤖 AI Expert Insights</div>", unsafe_allow_html=True)
                    
                    # AI Analysis is now always enabled with hardcoded key
                    for candidate in df.to_dict('records'):
                        eval_data = candidate.get("AI_Evaluation")
                        if eval_data and "error" not in eval_data and eval_data is not None:
                            with st.expander(f"📄 {candidate['Candidate']} - AI Score: {eval_data.get('match_score', 'N/A')}/100", expanded=False):
                                c1, c2, c3 = st.columns([1, 1, 2])
                                with c1:
                                    st.metric("AI Match Score", f"{eval_data.get('match_score', 0)}%")
                                    hiring_status = eval_data.get('hiring_status', 'N/A')
                                    if hiring_status == "Ready to Hire":
                                        st.success(f"🎯 {hiring_status}")
                                    else:
                                        st.error(f"❌ {hiring_status}")
                                
                                with c2:
                                    ats_score = eval_data.get('ats_friendly_score', 0)
                                    st.metric("ATS Score", f"{ats_score}/100")
                                    if eval_data.get('is_ats_friendly', False):
                                        st.success("✅ ATS Friendly")
                                    else:
                                        st.warning("⚠️ ATS Issues Detected")

                                with c3:
                                    st.caption("Executive Summary")
                                    st.write(eval_data.get('summary', 'No summary available.'))
                                
                                st.divider()
                                
                                cols_strengths, cols_weaknesses = st.columns(2)
                                with cols_strengths:
                                    st.success("💪 Strengths")
                                    for s in eval_data.get('strengths', []):
                                        st.markdown(f"- {s}")
                                with cols_weaknesses:
                                    st.error("🚩 Weaknesses")
                                    for w in eval_data.get('weaknesses', []):
                                        st.markdown(f"- {w}")

                                if eval_data.get('missing_critical_skills'):
                                    st.warning(f"⚠️ Missing Critical Skills: {', '.join(eval_data.get('missing_critical_skills', []))}")
                        elif eval_data and "error" in eval_data:
                            st.error(f"Error for {candidate['Candidate']}: {eval_data['error']}")
                        else:
                            st.info(f"PENDING AI Analysis for {candidate['Candidate']}...")


            else:
                st.error("❌ No valid candidates could be processed. Please check your PDF files.")

# ============================================================
# FOOTER
# ============================================================
st.markdown("""
    <div style="text-align: center; padding: 40px 0; margin-top: 60px; border-top: 1px solid rgba(255,255,255,0.1);">
        <p style="font-size: 14px; color: #64748b; margin: 0;">
            🧠 ResumeAI Pro v3.0 • Powered by Neural NLP • Built with Streamlit
        </p>
        <p style="font-size: 12px; color: #475569; margin-top: 8px;">
            TF-IDF • Cosine Similarity • Semantic Extraction • Bias Detection
        </p>
    </div>
""", unsafe_allow_html=True)